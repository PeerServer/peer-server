{
 "routePath": "/enter",
 "routeCode": "if((!params.name || params.name.length < 1) && (!session.user || session.user.length < 1)) {\n    return render_template(\"redirect.handlebars\", {redirectTo:\"index\"});\n}\nvar user = params.name ? params.name : session.user;\nsession.user = user;\nreturn render_template(\"requests.handlebars\", {\"user\": user});"
}