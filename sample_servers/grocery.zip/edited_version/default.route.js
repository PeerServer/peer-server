{
 "routePath": "/index",
 "routeCode": "return render_template('index.handlebars', {} );  // Change if desired"
}