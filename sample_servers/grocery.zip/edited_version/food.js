  function showError(error) {
            $("div.alert-error").html("<strong>Error</strong>: " + error);
            $("div.alert-error").show().delay(4000).fadeOut();
        }
        function showSuccess(success) {
            $("div.alert-success").html("<strong>Success</strong>: " + success);
            $("div.alert-success").show().delay(4000).fadeOut();
        }
        function addFood(foodType, optionalFood) {
            if(!foodType) {
                return;
            }
          onsuccess = function(res) {
              var result = $.parseJSON(res);
              if(result.error) {
                  showError(result.error);
              }
              else {
                  showSuccess(result.message);
                  if(!optionalFood) {
                      $(".newrequest." + foodType + " input.food").val("");
                      $(".newrequest." + foodType + " input.details").val("");
                      $(".newrequest." + foodType + " input.foodtype").val("");
                      !$(".subrequest input").blur();
                      !$(".subrequest button").blur();
                  }
                  updateSubRequests();
              }
          };
          onerror = function(ignore, error, errorThrown) {
              showError("It broke: " + errorThrown);
          };
            if (optionalFood) {
                var food = optionalFood;
                var details = "";
            }
            else {
                var food = $.trim($(".newrequest." + foodType + "  input.food").val());
                var details = $.trim($(".newrequest." + foodType + "  input.details").val());
            }
            var typeLower = foodType.toLowerCase();
            var user = $.trim($("span.username").text());
            if(!food || food.length < 1) {
                showError("Cannot create a blank food.")
                return;
            }
            $.ajax("addfood", {success: onsuccess, error: onerror, data: {"food": food, "details": details, "foodType": typeLower, "user": user}});
        }
        function updateSubRequests() {
            onsuccess = function(data) {
                $("div.subrequests").html(data);
            }
            onerror = function(ignore, error, errorThrown) {
                showError("It broke: " + errorThrown);
            }
            /* Don't make the call if it will override user changes. */
            if (!$(".subrequest input").is(":focus") && !$(".subrequest button").is(":focus")) {
                var user = $.trim($("span.username").text());
                $.ajax("subrequests",  {success: onsuccess, error: onerror, data: {"user": user}})
            }
        }
        $(document).ready(function() {
            updateSubRequests();
            setInterval(updateSubRequests, 5000);
        })