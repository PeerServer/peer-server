    function vote(votefor) {
        onsuccess = function(res) {
        $(".result").html("Vote counted");
        };
        onerror = function(ignore, error, errorThrown) {
            $(".result").html("vote rejected: " + errorThrown);
        };
        
        $.ajax("votefor", {success: onsuccess, error: onerror, data: {"name": votefor}});
    }