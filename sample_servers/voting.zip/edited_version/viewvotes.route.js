{
 "routePath": "/viewvotes",
 "routeCode": "var barack = database({\"votefor\": \"barack\"}).count();\nvar mitt = database({\"votefor\": \"mitt\"}).count();\nvar difference = Math.abs(barack - mitt);\nvar extra = \"\";\nvar winner = \"Nobody\";\nif (barack > mitt) {\n    winner = \"Barack\";\n    extra = \" by \" + difference;\n}\nelse if (mitt > barack) {\n    winner = \"Mitt\";\n    extra = \" by \" + difference;\n}\nvar message = winner + \" is winning \" + extra;\nreturn render_template(\"vote-results.handlebars\", {\"barack\": barack, \"mitt\": mitt, \"message\": message})"
}