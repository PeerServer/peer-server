{
 "routePath": "/viewvotes",
 "routeCode": "var countBarack = database({\"votefor\": \"barack\"}).count()\nvar countMitt = database({\"votefor\": \"mitt\"}).count()\n\nvar message = \"vote at \" + (new Date()).getMinutes()\nreturn render_template(\"vote-results.tmpl\", {\"countBarack\": countBarack, \"countMitt\": countMitt, \"message\": message})"
}