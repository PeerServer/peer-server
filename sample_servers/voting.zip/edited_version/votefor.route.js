{
 "routePath": "/votefor",
 "routeCode": "database.insert({\"votefor\": params.name});\nreturn \"Successfully cast vote for \" + params.name.charAt(0).toUpperCase() + params.name.slice(1);"
}