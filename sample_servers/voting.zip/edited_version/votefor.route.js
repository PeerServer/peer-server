{
 "routePath": "/votefor",
 "routeCode": "database.insert({\"votefor\": params.name})"
}