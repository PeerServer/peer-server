{
 "routePath": "/login",
 "routeCode": "var found = database({\"type\": \"account\", \"username\": params.username}).first()\nif(!found) {\n    return \"Not in database.\"\n}\nif(found.password == \"\" + hash(params.password + \"\" + found.salt)) {\n    session.loggedIn = true\n    return render_template(\"logged-in.handlebars\", {\"user\": params.username})\n} else {\n    return \"It broke.\"\n}"
}