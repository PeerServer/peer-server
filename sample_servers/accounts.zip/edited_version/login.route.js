{
 "routePath": "/login",
 "routeCode": "var found = database({\"type\": \"account\", \"username\": params.username}).first()\nif(!found) {\n    return \"Not in database.\"\n}\nconsole.log(\"FOUND: \")\nconsole.log(found);\nconsole.log(hash(params.password + \"\" + found.salt))\nif(found.password == \"\" + hash(params.password + \"\" + found.salt)) {\n    session.loggedIn = true\n    return \"<h3>It worked! Logged in as \" + params.username + \"</h3>\"\n} else {\n    return \"It broke.\"\n}"
}