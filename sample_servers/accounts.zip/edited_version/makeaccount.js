    function create() {
        onsuccess = function(res) {
        $(".message").html(res);
        };
        onerror = function(ignore, error, errorThrown) {
            $(".message").html("Not created: " + errorThrown);
        };
        var desiredname = $("#desiredname").val();
        var password = $("#desiredpassword").val();
        $.ajax("makeaccount", {success: onsuccess, error: onerror, data: {"username": desiredname, "password":password}});
    }