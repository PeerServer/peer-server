{
 "routePath": "/makeaccount",
 "routeCode": "salt = cryptoRandom(8);\nhashed = hash(params.password + \"\" + salt); \nvar found = database({\"type\": \"account\", \"username\": params.username}).first()\nif(!found) {\n    database.insert({\"type\": \"account\", \"username\": params.username, \"password\": hashed, \"salt\": salt});\n    return \"Account created for \" + _.escape(params.username) + \" with password salted and hashed\"\n} else {\n    return \"Sorry, username \" + _.escape(params.username) + \" is already taken.\"\n}"
}